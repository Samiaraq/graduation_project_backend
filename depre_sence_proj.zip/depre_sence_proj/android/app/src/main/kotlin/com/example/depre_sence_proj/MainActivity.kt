package com.example.depre_sence_proj

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
