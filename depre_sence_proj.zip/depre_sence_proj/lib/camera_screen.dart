// lib/camera_screen.dart
import 'package:flutter/material.dart';
import 'package:camera/camera.dart';
import 'dart:ui';
import 'app_colors.dart';

// --- (1) تحويل الصفحة إلى StatefulWidget ---
// نحتاج إلى StatefulWidget لإدارة حالة الكاميرا والصورة الملتقطة.
class CameraScreen extends StatefulWidget {
  const CameraScreen({Key? key}) : super(key: key);

  @override
  State<CameraScreen> createState() => _CameraScreenState();
}

class _CameraScreenState extends State<CameraScreen> {
  CameraController? _controller;
  List<CameraDescription>? _cameras;
  int _selectedCameraIndex = 0; // 0 للكاميرا الأمامية, 1 للخلفية

  // --- (2) متغير جديد لتخزين الصورة الملتقطة ---
  XFile? _capturedImage;

  // --- (3) متغير جديد للتحكم في وميض الفلاش ---
  bool _isFlashing = false;

  @override
  void initState() {
    super.initState();
    _initializeCamera();
  }

  Future<void> _initializeCamera() async {
    _cameras = await availableCameras();
    // نبحث عن الكاميرا الأمامية أولاً
    int frontCameraIndex = _cameras!.indexWhere((camera) => camera.lensDirection == CameraLensDirection.front);
    if (frontCameraIndex != -1) {
      _selectedCameraIndex = frontCameraIndex;
    }

    _controller = CameraController(_cameras![_selectedCameraIndex], ResolutionPreset.high);
    try {
      await _controller!.initialize();
      if (mounted) {
        setState(() {});
      }
    } catch (e) {
      print("Error initializing camera: $e");
    }
  }

  // --- (4) دالة جديدة لتبديل الكاميرا ---
  void _switchCamera() {
    if (_cameras == null || _cameras!.length < 2) return;

    // تبديل بين 0 و 1
    _selectedCameraIndex = (_selectedCameraIndex + 1) % _cameras!.length;

    // إعادة تهيئة الكاميرا بالعدسة الجديدة
    _initializeCamera();
  }

  // --- (5) دالة جديدة لالتقاط الصورة ---
  void _takePicture() async {
    if (_controller == null || !_controller!.value.isInitialized) {
      print('Error: camera is not initialized');
      return;
    }

    try {
      // التقط الصورة
      final XFile image = await _controller!.takePicture();

      // --- هنا التغييرات المهمة ---
      setState(() {
        _capturedImage = image; // 1. حفظ الصورة الملتقطة
        _isFlashing = true;     // 2. تفعيل حالة الوميض
      });

      // 3. إظهار الوميض ثم إخفاؤه
      Future.delayed(const Duration(milliseconds: 100), () {
        if (mounted) {
          setState(() {
            _isFlashing = false;
          });
        }
      });

      print('Picture saved to ${image.path}');

    } catch (e) {
      print('Error taking picture: $e');
    }
  }

  @override
  void dispose() {
    _controller?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final Size screenSize = MediaQuery.of(context).size;

    return Scaffold(
      backgroundColor: AppColors.background,
      body: Stack(
        children: [
          _buildDecorativeCircles(screenSize),
          SafeArea(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                const Padding(
                  padding: EdgeInsets.only(top: 40.0, bottom: 10.0),
                  child: Text('صورة للوجه', textAlign: TextAlign.center, style: TextStyle(fontFamily: 'Cairo', fontSize: 28, fontWeight: FontWeight.bold, color: AppColors.primaryText)),
                ),
                const Text('يرجى التقاط صورة واضحة لوجهك', textAlign: TextAlign.center, style: TextStyle(fontFamily: 'Cairo', fontSize: 16, color: AppColors.secondaryText)),
                const Spacer(),
                _buildCameraPreview(),
                const Spacer(),
                _buildControls(),
                const SizedBox(height: 20),
                _buildNextButton(),
                const Padding(
                  padding: EdgeInsets.all(16.0),
                  child: Text('لن يتم حفظ هذه الصورة، تستخدم فقط لتعديل الفلاتر', textAlign: TextAlign.center, style: TextStyle(fontFamily: 'Cairo', fontSize: 12, color: AppColors.secondaryText)),
                ),
              ],
            ),
          ),
          // --- (6) إضافة طبقة الوميض ---
          if (_isFlashing)
            Container(
              color: Colors.white.withOpacity(0.7),
            ),
        ],
      ),
    );
  }

  Widget _buildCameraPreview() {
    if (_controller == null || !_controller!.value.isInitialized) {
      return const Center(child: CircularProgressIndicator());
    }
    return Center(
      child: Container(
        width: 300,
        height: 400,
        decoration: BoxDecoration(
          color: Colors.black.withOpacity(0.2),
          borderRadius: BorderRadius.circular(30),
        ),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(30),
          child: Stack(
            fit: StackFit.expand,
            children: [
              CameraPreview(_controller!),
              // إضافة الدائرة البيضاوية فوق معاينة الكاميرا
              Center(
                child: Container(
                  width: 220,
                  height: 280,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(110), // نصف العرض
                    border: Border.all(color: Colors.white.withOpacity(0.5), width: 3),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildControls() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        const SizedBox(width: 64), // مساحة فارغة للموازنة
        // زر الالتقاط
        GestureDetector(
          onTap: _takePicture, // استدعاء دالة الالتقاط
          child: Container(
            width: 70,
            height: 70,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: Colors.white,
              border: Border.all(color: AppColors.buttonBackground, width: 4),
            ),
          ),
        ),
        const SizedBox(width: 20),
        // زر تبديل الكاميرا
        IconButton(
          icon: const Icon(Icons.flip_camera_ios, color: Colors.white, size: 30),
          onPressed: _switchCamera, // استدعاء دالة تبديل الكاميرا
        ),
      ],
    );
  }

  Widget _buildNextButton() {
    // --- (7) تغيير لون الزر بناءً على حالة الصورة ---
    final bool isPictureTaken = _capturedImage != null;

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 40.0),
      child: ElevatedButton(
        // إذا لم يتم التقاط صورة، اجعل onPressed = null لتعطيل الزر
        onPressed: isPictureTaken ? () {
          // TODO: Navigate to the next page
          print('Next button pressed! Image path: ${_capturedImage!.path}');
        } : null,
        style: ElevatedButton.styleFrom(
          // تغيير لون الخلفية بناءً على حالة الزر
          backgroundColor: isPictureTaken ? AppColors.buttonBackground : Colors.grey.shade600,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(30)),
          padding: const EdgeInsets.symmetric(vertical: 16),
        ),
        child: const Text('التالي', style: TextStyle(fontFamily: 'Cairo', fontSize: 18, color: AppColors.primaryText, fontWeight: FontWeight.bold)),
      ),
    );
  }

  // (دالة الدوائر الزخرفية تبقى كما هي)
  Widget _buildDecorativeCircles(Size screenSize) {
    return Stack(
      children: [
        Positioned(top: -screenSize.width * 0.3, right: -screenSize.width * 0.4, child: Container(width: screenSize.width * 0.9, height: screenSize.width * 0.9, decoration: const BoxDecoration(color: AppColors.decorativeCircle, shape: BoxShape.circle))),
        Positioned(bottom: -screenSize.width * 0.5, left: -screenSize.width * 0.3, child: Container(width: screenSize.width * 1.2, height: screenSize.width * 1.2, decoration: const BoxDecoration(color: AppColors.decorativeCircle, shape: BoxShape.circle))),
        BackdropFilter(filter: ImageFilter.blur(sigmaX: 80.0, sigmaY: 80.0), child: Container(color: Colors.transparent)),
      ],
    );
  }
}
