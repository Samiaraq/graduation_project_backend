//
//  Generated file. Do not edit.
//

import FlutterMacOS
import Foundation

import speech_to_text_macos

func RegisterGeneratedPlugins(registry: FlutterPluginRegistry) {
  SpeechToTextMacosPlugin.register(with: registry.registrar(forPlugin: "SpeechToTextMacosPlugin"))
}
