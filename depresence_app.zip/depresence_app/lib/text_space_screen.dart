// lib/text_space_screen.dart
import 'package:flutter/material.dart';
import 'dart:ui';
import 'package:speech_to_text/speech_to_text.dart' as stt;
import 'package:permission_handler/permission_handler.dart';
import 'app_colors.dart';
import 'questionnaire_welcome_screen.dart'; // استيراد الصفحة التالية

class TextSpaceScreen extends StatefulWidget {
  const TextSpaceScreen({Key? key}) : super(key: key);

  @override
  State<TextSpaceScreen> createState() => _TextSpaceScreenState();
}

class _TextSpaceScreenState extends State<TextSpaceScreen> {
  final TextEditingController _textController = TextEditingController();
  late stt.SpeechToText _speech;
  bool _isListening = false;

  @override
  void initState() {
    super.initState();
    _speech = stt.SpeechToText();
  }

  void _listen() async {
    // طلب إذن استخدام الميكروفون
    var status = await Permission.microphone.request();
    if (status != PermissionStatus.granted) {
      print("Microphone permission not granted");
      return;
    }

    if (!_isListening) {
      bool available = await _speech.initialize(
        onStatus: (val) => print('onStatus: $val'),
        onError: (val) => print('onError: $val'),
      );
      if (available) {
        setState(() => _isListening = true);
        _speech.listen(
          onResult: (val) => setState(() {
            _textController.text = val.recognizedWords;
          }),
        );
      }
    } else {
      setState(() => _isListening = false);
      _speech.stop();
    }
  }

  @override
  Widget build(BuildContext context) {
    final Size screenSize = MediaQuery.of(context).size;

    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        title: const Text('Text Space', style: TextStyle(color: Colors.white70, fontFamily: 'Beiruti')),
        backgroundColor: Colors.transparent,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios, color: Colors.white),
          onPressed: () => Navigator.of(context).pop(),
        ),
      ),
      body: Stack(
        children: [
          _buildDecorativeCircles(screenSize),
          SafeArea(
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  const SizedBox(height: 20),
                  const Text('مساحتك الآمنة', textAlign: TextAlign.center, style: TextStyle(fontFamily: 'Beiruti', fontSize: 32, fontWeight: FontWeight.bold, color: AppColors.primaryText)),
                  const SizedBox(height: 40),
                  const Text('بماذا تشعر الآن؟', textAlign: TextAlign.right, style: TextStyle(fontFamily: 'Beiruti', fontSize: 18, color: AppColors.primaryText, fontWeight: FontWeight.w600)),
                  const SizedBox(height: 10),
                  Expanded(
                    child: _buildTextField(),
                  ),
                  const SizedBox(height: 20),
                  ElevatedButton(
                    onPressed: () {
                      Navigator.of(context).push(MaterialPageRoute(builder: (context) => const QuestionnaireWelcomeScreen()));
                    },
                    style: ElevatedButton.styleFrom(backgroundColor: AppColors.buttonBackground, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(30)), padding: const EdgeInsets.symmetric(vertical: 16)),
                    child: const Text('التالي', style: TextStyle(fontFamily: 'Beiruti', fontSize: 18, color: AppColors.primaryText, fontWeight: FontWeight.bold)),
                  ),
                  const SizedBox(height: 40),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildTextField() {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(20),
        boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.1), blurRadius: 10, offset: const Offset(0, 5))],
      ),
      child: Stack(
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 8, 16, 50), // مساحة للمايكروفون
            child: TextField(
              controller: _textController,
              maxLines: null, // للسماح بعدد لا نهائي من الأسطر
              keyboardType: TextInputType.multiline,
              textAlign: TextAlign.right,
              style: const TextStyle(fontFamily: 'Beiruti', fontSize: 16, color: Colors.black87),
              decoration: const InputDecoration(
                hintText: 'اكتب هنا...',
                border: InputBorder.none,
              ),
            ),
          ),
          Positioned(
            left: 10,
            bottom: 10,
            child: IconButton(
              icon: Icon(_isListening ? Icons.mic : Icons.mic_none, color: AppColors.buttonBackground, size: 30),
              onPressed: _listen,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildDecorativeCircles(Size screenSize) {
    return Stack(
      children: [
        Positioned(top: -screenSize.width * 0.3, right: -screenSize.width * 0.4, child: Container(width: screenSize.width * 0.9, height: screenSize.width * 0.9, decoration: const BoxDecoration(color: AppColors.decorativeCircle, shape: BoxShape.circle))),
        Positioned(bottom: -screenSize.width * 0.5, left: -screenSize.width * 0.3, child: Container(width: screenSize.width * 1.2, height: screenSize.width * 1.2, decoration: const BoxDecoration(color: AppColors.decorativeCircle, shape: BoxShape.circle))),
        BackdropFilter(filter: ImageFilter.blur(sigmaX: 80.0, sigmaY: 80.0), child: Container(color: Colors.transparent)),
      ],
    );
  }
}
