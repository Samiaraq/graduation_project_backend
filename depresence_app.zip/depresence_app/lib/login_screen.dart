// lib/login_screen.dart
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'dart:ui';
import 'app_colors.dart';
import 'signup_screen.dart';
import 'camera_screen.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({Key? key}) : super(key: key);

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  // --- (1) إضافة مفتاح للـ Form ---
  final _formKey = GlobalKey<FormState>();

  // --- (2) إنشاء Controllers (اختياري هنا لكنها ممارسة جيدة) ---
  final _emailController = TextEditingController();
  final _passwordController = TextEditingController();

  // --- (3) دالة لعملية تسجيل الدخول ---
  void _submitForm() {
    // التحقق من صحة كل الحقول في الـ Form
    if (_formKey.currentState!.validate()) {
      // إذا كانت كل الحقول صحيحة
      print('Form is valid!');
      print('Email: ${_emailController.text}');

      // TODO: Add actual login logic here (e.g., call an API)

      // بعد نجاح تسجيل الدخول، انتقل إلى صفحة الكاميرا
      // استخدام pushAndRemoveUntil يمنع المستخدم من العودة إلى صفحة تسجيل الدخول
      Navigator.of(context).pushAndRemoveUntil(
        MaterialPageRoute(builder: (context) => const CameraScreen()),
            (Route<dynamic> route) => false,
      );
    } else {
      // إذا كان هناك حقل واحد على الأقل غير صحيح
      print('Form is invalid!');
    }
  }

  @override
  void dispose() {
    // التخلص من الـ Controllers
    _emailController.dispose();
    _passwordController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final Size screenSize = MediaQuery.of(context).size;

    return Scaffold(
      backgroundColor: AppColors.background,
      // إضافة سهم للرجوع إلى الصفحة الرئيسية
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios, color: Colors.white),
          onPressed: () => Navigator.of(context).pop(),
        ),
      ),
      body: Stack(
        children: [
          _buildDecorativeCircles(screenSize),
          SafeArea(
            child: Center(
              // --- (4) إضافة ويدجت Form ---
              child: Form(
                key: _formKey, // ربط المفتاح بالـ Form
                child: SingleChildScrollView(
                  padding: const EdgeInsets.symmetric(horizontal: 30.0),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      const Text('ابدأ رحلتك في التعافي', textAlign: TextAlign.center, style: TextStyle(fontFamily: 'Beiruti', fontSize: 28, fontWeight: FontWeight.bold, color: AppColors.primaryText)),
                      const SizedBox(height: 8),
                      const Text('تسجيل الدخول', textAlign: TextAlign.center, style: TextStyle(fontFamily: 'Beiruti', fontSize: 20, color: AppColors.secondaryText)),
                      const SizedBox(height: 40),

                      // --- (5) تغيير TextField إلى TextFormField وإضافة validator ---
                      _buildTextFormField(
                        controller: _emailController,
                        label: 'الإيميل',
                        hint: 'أدخل بريدك الإلكتروني',
                        keyboardType: TextInputType.emailAddress,
                        validator: (value) {
                          if (value == null || value.isEmpty) {
                            return 'الرجاء إدخال البريد الإلكتروني';
                          }
                          if (!RegExp(r'\S+@\S+\.\S+').hasMatch(value)) {
                            return 'الرجاء إدخال بريد إلكتروني صحيح';
                          }
                          return null; // يعني أن القيمة صحيحة
                        },
                      ),
                      const SizedBox(height: 20),
                      _buildTextFormField(
                        controller: _passwordController,
                        label: 'كلمة المرور',
                        hint: '*********',
                        obscureText: true,
                        validator: (value) {
                          if (value == null || value.isEmpty) {
                            return 'الرجاء إدخال كلمة المرور';
                          }
                          return null;
                        },
                      ),
                      Align(
                        alignment: Alignment.centerLeft,
                        child: TextButton(
                          onPressed: () { /* TODO: Implement forgot password */ },
                          child: const Text('نسيت كلمة المرور؟', style: TextStyle(fontFamily: 'Beiruti', color: AppColors.secondaryText)),
                        ),
                      ),
                      const SizedBox(height: 20),

                      // --- (6) تعديل الزر ليستدعي دالة التحقق ---
                      ElevatedButton(
                        onPressed: _submitForm, // استدعاء دالة التحقق عند الضغط
                        style: ElevatedButton.styleFrom(backgroundColor: AppColors.buttonBackground, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(30)), padding: const EdgeInsets.symmetric(vertical: 16), elevation: 5, shadowColor: Colors.black.withOpacity(0.2)),
                        child: const Text('تسجيل الدخول', style: TextStyle(fontFamily: 'Beiruti', fontSize: 18, color: AppColors.primaryText, fontWeight: FontWeight.bold)),
                      ),
                      const SizedBox(height: 30),
                      _buildSignUpLink(context),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  // --- (7) تعديل دالة بناء الحقول لتصبح TextFormField ---
  Widget _buildTextFormField({
    required TextEditingController controller,
    required String label,
    required String hint,
    bool obscureText = false,
    TextInputType keyboardType = TextInputType.text,
    String? Function(String?)? validator,
  }) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(label, style: const TextStyle(fontFamily: 'Beiruti', fontSize: 16, color: AppColors.primaryText, fontWeight: FontWeight.w600)),
        const SizedBox(height: 8),
        TextFormField( // تغيير هنا
          controller: controller,
          obscureText: obscureText,
          keyboardType: keyboardType,
          validator: validator, // إضافة الـ validator
          style: const TextStyle(color: Colors.black87, fontFamily: 'Beiruti'),
          decoration: InputDecoration(
            hintText: hint,
            hintStyle: TextStyle(color: Colors.grey.shade500),
            filled: true,
            fillColor: Colors.white.withOpacity(0.9),
            border: OutlineInputBorder(borderRadius: BorderRadius.circular(30), borderSide: BorderSide.none),
            errorBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(30), borderSide: const BorderSide(color: Colors.red, width: 2)),
            focusedErrorBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(30), borderSide: const BorderSide(color: Colors.red, width: 2)),
            contentPadding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
          ),
        ),
      ],
    );
  }

  // (باقي الدوال المساعدة تبقى كما هي بدون تغيير)
  Widget _buildSignUpLink(BuildContext context) {
    return Center(
      child: RichText(
        text: TextSpan(
          style: const TextStyle(fontFamily: 'Beiruti', fontSize: 14, color: AppColors.secondaryText),
          children: [
            const TextSpan(text: 'ليس لديك حساب؟ '),
            TextSpan(
              text: 'قم بإنشاء حساب',
              style: const TextStyle(color: AppColors.primaryText, fontWeight: FontWeight.bold, decoration: TextDecoration.underline),
              recognizer: TapGestureRecognizer()
                ..onTap = () {
                  Navigator.pushReplacement(context, MaterialPageRoute(builder: (context) => const SignUpScreen()));
                },
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildDecorativeCircles(Size screenSize) {
    return Stack(
      children: [
        Positioned(top: -screenSize.width * 0.3, right: -screenSize.width * 0.4, child: Container(width: screenSize.width * 0.9, height: screenSize.width * 0.9, decoration: const BoxDecoration(color: AppColors.decorativeCircle, shape: BoxShape.circle))),
        Positioned(bottom: -screenSize.width * 0.5, left: -screenSize.width * 0.3, child: Container(width: screenSize.width * 1.2, height: screenSize.width * 1.2, decoration: const BoxDecoration(color: AppColors.decorativeCircle, shape: BoxShape.circle))),
        BackdropFilter(filter: ImageFilter.blur(sigmaX: 80.0, sigmaY: 80.0), child: Container(color: Colors.transparent)),
      ],
    );
  }
}
