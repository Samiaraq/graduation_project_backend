// lib/main.dart
import 'package:flutter/material.dart';
import 'welcome_screen.dart'; // استيراد الشاشة الأولى فقط

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      // --- إعدادات عامة للتطبيق ---
      title: 'DepreSence', // يمكنك تغيير هذا الاسم كما تشائين
      debugShowCheckedModeBanner: false, // لإخفاء شريط "Debug" الأحمر
      theme: ThemeData(
        // هنا نحدد الخط الافتراضي للتطبيق كله
        // هذا يضمن أن كل النصوص ستستخدم خط "Cairo" ما لم نحدد غير ذلك
        fontFamily: 'Beiruti',

        // يمكنك تحديد ألوان أساسية هنا إذا أردت
        primarySwatch: Colors.blue,
      ),

      // --- إعدادات اتجاه اللغة (مهم جداً للغة العربية) ---
      builder: (context, child) {
        return Directionality(
          textDirection: TextDirection.rtl, // اجعل كل التطبيق من اليمين لليسار
          child: child!,
        );
      },

      // --- نقطة انطلاق التطبيق ---
      // هنا نخبر التطبيق أن يبدأ دائماً من شاشة الترحيب
      home: const WelcomeScreen(),
    );
  }
}
