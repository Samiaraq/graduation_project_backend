// lib/camera_screen.dart
import 'text_space_screen.dart';
import 'package:flutter/material.dart';
import 'package:camera/camera.dart';
import 'dart:ui';
import 'app_colors.dart';

class CameraScreen extends StatefulWidget {
  const CameraScreen({Key? key}) : super(key: key);

  @override
  State<CameraScreen> createState() => _CameraScreenState();
}

class _CameraScreenState extends State<CameraScreen> {
  List<CameraDescription> _cameras = [];
  CameraController? _controller;
  int _selectedCameraIndex = -1; // -1 يعني لم يتم الاختيار بعد

  XFile? _capturedImage;
  bool _isFlashing = false;

  @override
  void initState() {
    super.initState();
    _initializeCameras();
  }

  Future<void> _initializeCameras() async {
    _cameras = await availableCameras();
    if (_cameras.isEmpty) {
      print("No cameras found");
      return;
    }
    // البحث عن الكاميرا الأمامية كخيار افتراضي
    int frontCameraIndex = _cameras.indexWhere((camera) => camera.lensDirection == CameraLensDirection.front);

    // إذا لم توجد كاميرا أمامية، استخدم أول كاميرا متاحة (الخلفية غالباً)
    _selectedCameraIndex = (frontCameraIndex != -1) ? frontCameraIndex : 0;

    _initializeCameraController();
  }

  Future<void> _initializeCameraController() async {
    if (_selectedCameraIndex == -1) return;

    // التخلص من الكنترولر القديم قبل إنشاء واحد جديد
    await _controller?.dispose();

    _controller = CameraController(
      _cameras[_selectedCameraIndex],
      ResolutionPreset.high,
      enableAudio: false, // لا نحتاج لتسجيل الصوت مع الصورة
    );

    try {
      await _controller!.initialize();
      if (mounted) {
        setState(() {}); // إعادة بناء الواجهة بعد تهيئة الكاميرا
      }
    } catch (e) {
      print("Error initializing camera: $e");
    }
  }

  // دالة تبديل الكاميرا (أصبحت أكثر استقراراً)
  void _switchCamera() {
    if (_cameras.length < 2) return; // لا يمكن التبديل إذا كانت هناك كاميرا واحدة فقط

    // تبديل بين الكاميرا الأمامية والخلفية
    _selectedCameraIndex = (_selectedCameraIndex + 1) % _cameras.length;
    _initializeCameraController();
  }

  void _takePicture() async {
    if (_controller == null || !_controller!.value.isInitialized) return;

    try {
      final XFile image = await _controller!.takePicture();

      setState(() {
        _capturedImage = image;
        _isFlashing = true; // تفعيل الوميض
      });

      // إخفاء الوميض بعد فترة قصيرة
      Future.delayed(const Duration(milliseconds: 120), () {
        if (mounted) setState(() => _isFlashing = false);
      });

    } catch (e) {
      print('Error taking picture: $e');
    }
  }

  @override
  void dispose() {
    _controller?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final Size screenSize = MediaQuery.of(context).size;

    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        title: const Text('Camera', style: TextStyle(color: Colors.white54, fontFamily: 'Beiruti', fontWeight: FontWeight.w300)),
        backgroundColor: Colors.transparent,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios, color: Colors.white),
          onPressed: () => Navigator.of(context).pop(),
        ),
      ),
      body: Stack(
        children: [
          _buildDecorativeCircles(screenSize), // الخلفية الزخرفية الثابتة
          SafeArea(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                const SizedBox(height: 20),
                const Text('صورة للوجه', textAlign: TextAlign.center, style: TextStyle(fontFamily: 'Beiruti', fontSize: 32, fontWeight: FontWeight.bold, color: AppColors.primaryText)),
                const SizedBox(height: 10),
                const Text('يرجى التقاط صورة واضحة لوجهك', textAlign: TextAlign.center, style: TextStyle(fontFamily: 'Beiruti', fontSize: 16, color: AppColors.secondaryText)),
                const Spacer(),
                _buildCameraPreview(), // معاينة الكاميرا مع الوميض بداخلها
                const Spacer(),
                _buildControls(),
                const SizedBox(height: 20),
                _buildNextButton(),
                const Padding(
                  padding: EdgeInsets.fromLTRB(16, 16, 16, 24),
                  child: Text('لن يتم حفظ هذه الصورة، تستخدم فقط لتعديل الفلاتر', textAlign: TextAlign.center, style: TextStyle(fontFamily: 'Beiruti', fontSize: 12, color: AppColors.secondaryText)),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // --- التعديل الرئيسي هنا: الوميض أصبح داخل هذا الويدجت فقط ---
  Widget _buildCameraPreview() {
    return Center(
      child: Container(
        width: 300,
        height: 400,
        decoration: BoxDecoration(
          color: Colors.black.withOpacity(0.1),
          borderRadius: BorderRadius.circular(30),
          border: Border.all(color: Colors.white.withOpacity(0.2), width: 1),
        ),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(30),
          child: Stack(
            fit: StackFit.expand,
            children: [
              // طبقة الكاميرا
              if (_controller != null && _controller!.value.isInitialized)
                CameraPreview(_controller!)
              else
                const Center(child: CircularProgressIndicator(color: Colors.white)),

              // طبقة الإطار البيضاوي
              Center(
                child: Container(
                  width: 220,
                  height: 280,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(110),
                    border: Border.all(color: Colors.white.withOpacity(0.4), width: 2),
                  ),
                ),
              ),

              // طبقة الوميض (تظهر فقط عند الالتقاط)
              if (_isFlashing)
                Container(
                  color: Colors.white.withOpacity(0.6),
                ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildControls() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      crossAxisAlignment: CrossAxisAlignment.center,
      children: [
        const SizedBox(width: 64), // مساحة فارغة للموازنة
        GestureDetector(
          onTap: _takePicture,
          child: Container(
            width: 70,
            height: 70,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: Colors.white,
              border: Border.all(color: AppColors.buttonBackground.withOpacity(0.8), width: 4),
            ),
          ),
        ),
        const SizedBox(width: 15),
        IconButton(
          icon: const Icon(Icons.flip_camera_ios_outlined, color: Colors.white, size: 28),
          onPressed: _switchCamera,
        ),
      ],
    );
  }

  Widget _buildNextButton() {
    final bool isPictureTaken = _capturedImage != null;
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 40.0),
      child: ElevatedButton(
        onPressed: isPictureTaken ? () {
          // الربط مع صفحة الكتابة
          Navigator.of(context).push(MaterialPageRoute(builder: (context) => const TextSpaceScreen()));
        } : null,
        style: ElevatedButton.styleFrom(
          backgroundColor: isPictureTaken ? AppColors.buttonBackground : Colors.grey.shade600,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(30)),
          padding: const EdgeInsets.symmetric(vertical: 16),
          elevation: isPictureTaken ? 5 : 0,
        ),
        child: const Text('التالي', style: TextStyle(fontFamily: 'Beiruti', fontSize: 18, color: AppColors.primaryText, fontWeight: FontWeight.bold)),
      ),
    );
  }

  // دالة الدوائر الزخرفية الثابتة لكل الصفحات
  Widget _buildDecorativeCircles(Size screenSize) {
    return Stack(
      children: [
        Positioned(top: -screenSize.width * 0.3, right: -screenSize.width * 0.4, child: Container(width: screenSize.width * 0.9, height: screenSize.width * 0.9, decoration: const BoxDecoration(color: AppColors.decorativeCircle, shape: BoxShape.circle))),
        Positioned(bottom: -screenSize.width * 0.5, left: -screenSize.width * 0.3, child: Container(width: screenSize.width * 1.2, height: screenSize.width * 1.2, decoration: const BoxDecoration(color: AppColors.decorativeCircle, shape: BoxShape.circle))),
        BackdropFilter(filter: ImageFilter.blur(sigmaX: 80.0, sigmaY: 80.0), child: Container(color: Colors.transparent)),
      ],
    );
  }
}
