import 'package:flutter/material.dart';
import 'dart:ui';
import 'app_colors.dart';

class Question9Screen extends StatelessWidget {
  const Question9Screen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final Size screenSize = MediaQuery.of(context).size;

    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios, color: Colors.white),
          onPressed: () => Navigator.of(context).pop(),
        ),
        title: const Text(
          'Question 9 / 9',
          style: TextStyle(
            fontFamily: 'Beiruti',
            color: Colors.white70,
          ),
        ),
        centerTitle: true,
      ),
      body: Stack(
        children: [
          _buildDecorativeCircles(screenSize),
          SafeArea(
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20.0, vertical: 10),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  const Align(
                    alignment: Alignment.topLeft,
                    child: Text(
                      'Question 9/9',
                      style: TextStyle(
                        fontFamily: 'Just Another Hand',
                        fontSize: 18,
                        color: AppColors.primaryText,
                      ),
                    ),
                  ),
                  const SizedBox(height: 10),
                  const Text(
                    'الأفكار بأنك ستكون أفضل لو لم تكن موجودًا',
                    textAlign: TextAlign.right,
                    style: TextStyle(
                      fontFamily: 'Traditional Arabic',
                      fontSize: 24,
                      fontWeight: FontWeight.bold,
                      color: AppColors.primaryText,
                    ),
                  ),
                  const SizedBox(height: 20),
                  ...['0','1','2','3'].map(
                        (option) => Padding(
                      padding: const EdgeInsets.symmetric(vertical: 4),
                      child: ElevatedButton(
                        onPressed: () {},
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.grey[300],
                          foregroundColor: Colors.black87,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(20),
                          ),
                          padding: const EdgeInsets.symmetric(vertical: 12),
                        ),
                        child: Text(option, style: const TextStyle(fontFamily: 'Beiruti', fontSize: 18)),
                      ),
                    ),
                  ),
                  const Spacer(),
                  ElevatedButton(
                    onPressed: () {
                      // نهاية الاستبيان، ممكن ترجع للصفحة الرئيسية أو تظهر النتيجة
                      Navigator.of(context).pop();
                    },
                    style: ElevatedButton.styleFrom(
                      backgroundColor: AppColors.buttonBackground,
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(30)),
                      padding: const EdgeInsets.symmetric(vertical: 16),
                    ),
                    child: const Text(
                      'التالي',
                      style: TextStyle(
                        fontFamily: 'Beiruti',
                        fontSize: 18,
                        color: AppColors.primaryText,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildDecorativeCircles(Size screenSize) {
    return Stack(
      children: [
        Positioned(
          top: -screenSize.width * 0.3,
          right: -screenSize.width * 0.4,
          child: Container(
            width: screenSize.width * 0.9,
            height: screenSize.width * 0.9,
            decoration: const BoxDecoration(color: AppColors.decorativeCircle, shape: BoxShape.circle),
          ),
        ),
        Positioned(
          bottom: -screenSize.width * 0.5,
          left: -screenSize.width * 0.3,
          child: Container(
            width: screenSize.width * 1.2,
            height: screenSize.width * 1.2,
            decoration: const BoxDecoration(color: AppColors.decorativeCircle, shape: BoxShape.circle),
          ),
        ),
        BackdropFilter(filter: ImageFilter.blur(sigmaX: 80.0, sigmaY: 80.0), child: Container(color: Colors.transparent)),
      ],
    );
  }
}