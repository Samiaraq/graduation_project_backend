//
// Generated file. Do not edit.
// This file is generated from template in file `flutter_tools/lib/src/flutter_plugins.dart`.
//

// @dart = 3.10

import 'dart:io'; // flutter_ignore: dart_io_import.
import 'package:camera_android/camera_android.dart' as camera_android;
import 'package:camera_avfoundation/camera_avfoundation.dart' as camera_avfoundation;
import 'package:speech_to_text_macos/speech_to_text_macos.dart' as speech_to_text_macos;

@pragma('vm:entry-point')
class _PluginRegistrant {

  @pragma('vm:entry-point')
  static void register() {
    if (Platform.isAndroid) {
      try {
        camera_android.AndroidCamera.registerWith();
      } catch (err) {
        print(
          '`camera_android` threw an error: $err. '
          'The app may not function as expected until you remove this plugin from pubspec.yaml'
        );
      }

    } else if (Platform.isIOS) {
      try {
        camera_avfoundation.AVFoundationCamera.registerWith();
      } catch (err) {
        print(
          '`camera_avfoundation` threw an error: $err. '
          'The app may not function as expected until you remove this plugin from pubspec.yaml'
        );
      }

    } else if (Platform.isLinux) {
    } else if (Platform.isMacOS) {
      try {
        speech_to_text_macos.SpeechToTextMacOS.registerWith();
      } catch (err) {
        print(
          '`speech_to_text_macos` threw an error: $err. '
          'The app may not function as expected until you remove this plugin from pubspec.yaml'
        );
      }

    } else if (Platform.isWindows) {
    }
  }
}
